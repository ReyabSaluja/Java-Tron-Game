import java.awt.Graphics;
import java.awt.*;

/**
 * The Player class is a individual player controlled in the main program.
 * @see Tron
 * @author Evan Jiang
 * @author Reyab Saluja
 * @version "1.8.0_322"
 */
public class Player {
    private int x;
    private int y;
    private int width;
    private int height;
    private int stepX;
    private int stepY;
    private int score = 0;
    private Color color;
    private boolean pace;
    //------------------------------------------------------------------------------     
    Player(int x, int y, Color color, int stepX, int stepY) {
        this.x = x;
        this.y = y;
        this.color = color;
        this.stepX = stepX;
        this.stepY = stepY;
    }
    
    //------------------------------------------------------------------------------
    public int getX() {
        return this.x;
    }
    
    public void setX(int x) {
        this.x = x;
    }
    
    public int getY() {
        return this.y;
    }
    
    public void setY(int y) {
        this.y = y;
    }
    
    public int getWidth() {
        return this.width;
    }
    
    public void setWidth(int width) {
        this.width = width;
    }
    
    public int getHeight() {
        return this.height;
    }
    
    public void setHeight(int height) {
        this.height = height;
    }
    
    public int getStepX() {
        return this.stepX;
    }

    public void setStepX(int stepX) {
        this.stepX = stepX;
    }
    
    public int getStepY() {
        return this.stepY;
    }
    
    public void setStepY(int stepY) {
        this.stepY = stepY;
    }
    
    public int getScore() {
        return this.score;
    }
    
    public Color getColor() {
        return this.color;
    }
    
    public void setColor(Color color) {
        this.color = color;
    }

    /** 
     * Set the player in the left direction.
     */
    public void left() {
        if(this.pace){
            this.stepX = -Const.TILE_SIZE;
            this.stepY = 0;
            this.pace = false;
        }
    }

    /** 
     * Set the player in the right direction.
     */
    public void right() {
        if(this.pace){
            this.stepX = Const.TILE_SIZE;
            this.stepY = 0;
            this.pace = false;
        }
    }

    /** 
     * Set the player in the up direction.
     */
    public void up() {
        if(this.pace){
            this.stepX = 0;
            this.stepY = -Const.TILE_SIZE;
            this.pace = false;
        }
    }

    /** 
     * Set the player in the down direction.
     */
    public void down() {
        if(this.pace){
            this.stepX = 0;
            this.stepY = Const.TILE_SIZE;
            this.pace = false;
        }
    }
    //------------------------------------------------------------------------------     

    /** 
     * Draws the player onto a Graphics panel.
     * @param g
     */
    public void draw(Graphics g) {
        g.setColor(this.color);
        g.fillRect(this.x, this.y, Const.TILE_SIZE, Const.TILE_SIZE);
        g.setColor(Const.WHITE_COLOR);
        g.drawRect(this.x, this.y, Const.TILE_SIZE - 1, Const.TILE_SIZE - 1);
    }
    
    /** 
     * Checks if the passed coordinates is inside the player.
     * @param x
     * @param y
     * @return boolean
     */
    public boolean contains(int x, int y) {
        return (x > this.x && x < this.x + Const.TILE_SIZE && y > this.y && y < this.y + Const.TILE_SIZE);
    }
    
    /** 
     * Check if the player is moving vertically.
     * @return boolean
     */
    public boolean yPositive() {
        return this.stepY == 0;
    }
    
    /** 
     * Check if the player is either moving horizontally.
     * @return boolean
     */
    public boolean xPositive() {
        return this.stepX == 0;
    }
    //------------------------------------------------------------------------------     
    /** 
     * Updates the x and y of the player depending on the steps.
     */
    public void move() {
        this.x = this.x + this.stepX;
        this.y = this.y + this.stepY;
        this.pace = true;
    }
    
    /** 
     * Checks if the player is on the left side of a x coordinate.
     * @param boundary
     * @return boolean
     */
    public boolean crossingLeft(int boundary) {
        return (this.x < boundary);
    }
    
    /** 
     * Checks if the player is on the right side of a x coordinate.
     * @param boundary
     * @return boolean
     */
    public boolean crossingRight(int boundary) {
        return (this.x + Const.TILE_SIZE > boundary);
    }
    
    /** 
     * Checks if the player is on the top side of a y coordinate.
     * @param boundary
     * @return boolean
     */
    public boolean crossingTop(int boundary) {
        return (this.y < boundary);
    }
    
    /** 
     * Checks if the player is on the bottom side of a y coordinate.
     * @param boundary
     * @return boolean
     */
    public boolean crossingBottom(int boundary) {
        return (this.y + Const.TILE_SIZE > boundary);
    }
    
    /** 
     * Sets the position of the player to the passed coordinates.
     * @param x
     * @param y
     */
    public void reset(int x, int y) {
        this.x = x;
        this.y = y;
    }

    /** 
     * Increases the player score by 1.
     */
    public void addPlayerScore() {
        this.score += 1;
    }

    /** 
     * Sets the player score to 0.
     */
    public void resetScore() {
        this.score = 0;
    }
}