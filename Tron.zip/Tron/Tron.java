import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

/**
 * The Tron class is a playable clone of the 1982 arcade video game, Tron. 
 * @see Player
 * @see Tile
 * @see Menu
 * @see MenuItem
 * @see Sound
 * @author David Daniliuc
 * @author Reyab Saluja
 * @author Evan Jiang
 * @version "1.8.0_322"
 */
public class Tron {
    JFrame frame;
    GraphicsPanel canvas;
    KeyboardListener keyboardListener;
    MenuMouseListener menuMouseListener;
    MenuMotionListener menuMotionListener;
    // Declaring Game State
    String gameState = "Start Menu";
    // Creating an Array of Player Colors
    Color[] playerColorCycle = {
        Const.CYAN_COLOR,
        Const.ORANGE_COLOR,
        Const.YELLOW_COLOR,
        Const.WHITE_COLOR
    };
    // Creating an Array of Difficulties
    int currentCycleP1 = 0;
    int currentCycleP2 = 1;
    String[] difficultyCycle = {
        "Easy Level",
        "Medium Level",
        "Hard Level"
    };
    int currentDifficultyCycle;
    int difficultyInt = Const.DELAY_EASYLEVEL;

    // Start Menu Components
    MenuItem[] startMenuItems = {
        new Text(0, 0, "TRON", Const.VERY_LARGE_FONT, Const.LIGHT_BLUE_COLOR),
        new Button(new Rect(0, 0, Const.BLACK_COLOR, 100, 50), new Text(0, 0, "START GAME", Const.LARGE_FONT_MENU, Const.LIGHT_BLUE_COLOR), MouseEvent.MOUSE_CLICKED, "Choose Color Menu", Const.CYAN_COLOR, true, true),
        new Button(new Rect(0, 0, Const.BLACK_COLOR, 100, 50), new Text(0, 0, "CREDITS", Const.LARGE_FONT_MENU, Const.LIGHT_BLUE_COLOR), MouseEvent.MOUSE_CLICKED, "Credits Menu", Const.CYAN_COLOR, true, true),
        new Image(180, 110, "Images/tron_driver.png")
    };
    Menu startMenu = new Menu(0, 0, Const.WIDTH, Const.HEIGHT, Const.BLACK_COLOR, startMenuItems);

    // Credit Menu Components
    MenuItem[] creditsMenuItems = {
        new Text(0, 0, "CREDITS:", Const.VERY_LARGE_FONT, Const.LIGHT_BLUE_COLOR),
        new Text(0, 0, "Lead Programmer: David Daniluc", Const.MEDIUM_FONT_MENU, Const.CYAN_COLOR),
        new Text(0, 0, "Sound Designer: Evan Jiang", Const.MEDIUM_FONT_MENU, Const.CYAN_COLOR),
        new Text(0, 0, "Game Developer: Evan Jiang & Reyab Saluja", Const.MEDIUM_FONT_MENU, Const.CYAN_COLOR),
        new Text(0, 0, "Lead UI Programmer: Reyab Saluja", Const.MEDIUM_FONT_MENU, Const.CYAN_COLOR),
        new Text(0, 0, "Menu Developer: David Danliuc", Const.MEDIUM_FONT_MENU, Const.CYAN_COLOR),
        new Text(0, 0, "Menu Designer: Reyab Saluja & David Danliuc", Const.MEDIUM_FONT_MENU, Const.CYAN_COLOR),
        new Button(new Rect(0, 0, Const.BLACK_COLOR, 100, 70), new Text(0, 0, "GO BACK", Const.LARGE_FONT_MENU, Const.LIGHT_BLUE_COLOR), MouseEvent.MOUSE_CLICKED, "Start Menu", Const.CYAN_COLOR, false, true)
    };
    Menu creditsMenu = new Menu(0, 0, Const.WIDTH, Const.HEIGHT, Const.BLACK_COLOR, creditsMenuItems);

    // Choose Color Menu Components
    MenuItem[] chooseColorItems = {
        new Text(250, 100, "CHOOSE COLOR", Const.VERY_LARGE_FONT_MENU, Const.LIGHT_BLUE_COLOR),
        new Button(new Rect(300, 430, Const.BLACK_COLOR, 100, 50), new Text(0, 0, "CONTINUE", Const.VERY_LARGE_FONT_MENU, Const.LIGHT_BLUE_COLOR), MouseEvent.MOUSE_CLICKED, "Choose Difficulty Menu", Const.CYAN_COLOR, true, true),
        //Player1
        new Rect(115, 255, Const.CYAN_COLOR, 100, 100),
        new Button(new Rect(250, 250, Const.BLACK_COLOR, 80, 115), new Text(0, 0, "", Const.LARGE_FONT, Const.LIGHT_BLUE_COLOR), MouseEvent.MOUSE_CLICKED, "P1 Cycle Color Right", Const.CYAN_COLOR, false, true),
        new Image(250, 250, "Images/rightarrow.png"),
        new Button(new Rect(0, 250, Const.BLACK_COLOR, 80, 115), new Text(0, 0, "", Const.LARGE_FONT, Const.LIGHT_BLUE_COLOR), MouseEvent.MOUSE_CLICKED, "P1 Cycle Color Left", Const.CYAN_COLOR, false, true),
        new Image(10, 250, "Images/leftarrow.png"),
        //Player2
        new Rect(600, 255, Const.ORANGE_COLOR, 100, 100),
        new Button(new Rect(720, 250, Const.BLACK_COLOR, 80, 115), new Text(0, 0, "", Const.LARGE_FONT, Const.LIGHT_BLUE_COLOR), MouseEvent.MOUSE_CLICKED, "P2 Cycle Color Right", Const.CYAN_COLOR, false, true),
        new Image(720, 250, "Images/rightarrow.png"),
        new Button(new Rect(500, 250, Const.BLACK_COLOR, 80, 115), new Text(0, 0, "", Const.LARGE_FONT, Const.LIGHT_BLUE_COLOR), MouseEvent.MOUSE_CLICKED, "P2 Cycle Color Left", Const.CYAN_COLOR, false, true),
        new Image(500, 250, "Images/leftarrow.png")
    };
    Menu chooseColorMenu = new Menu(0, 0, Const.WIDTH, Const.HEIGHT, Const.BLACK_COLOR, chooseColorItems);

    // Choose Difficulty Menu Components
    MenuItem[] chooseDifficultyMenuItems = {
        new Text(165, 100, "PICK YOUR DIFFICULTY", Const.VERY_LARGE_FONT_MENU, Const.LIGHT_BLUE_COLOR),
        new Button(new Rect(300, 430, Const.BLACK_COLOR, 100, 50), new Text(0, 0, "CONTINUE", Const.VERY_LARGE_FONT_MENU, Const.LIGHT_BLUE_COLOR), MouseEvent.MOUSE_CLICKED, "Game", Const.CYAN_COLOR, true, true),
        // Choose Difficulty Buttons
        new Text(315, 300, "Easy Level", Const.LARGE_FONT_MENU, Const.LIGHT_BLUE_COLOR),
        new Button(new Rect(520, 250, Const.BLACK_COLOR, 80, 115), new Text(0, 0, "", Const.LARGE_FONT, Const.LIGHT_BLUE_COLOR), MouseEvent.MOUSE_CLICKED, "Choose Difficulty Cycle Right", Const.CYAN_COLOR, false, true),
        new Image(520, 250, "Images/rightarrow.png"),
        new Button(new Rect(200, 250, Const.BLACK_COLOR, 80, 115), new Text(0, 0, "", Const.LARGE_FONT, Const.LIGHT_BLUE_COLOR), MouseEvent.MOUSE_CLICKED, "Choose Difficulty Cycle Left", Const.CYAN_COLOR, false, true),
        new Image(200, 250, "Images/leftarrow.png")
    };
    Menu chooseDifficultyMenu = new Menu(0, 0, Const.WIDTH, Const.HEIGHT, Const.BLACK_COLOR, chooseDifficultyMenuItems);

    // Death Screen Menu Components
    MenuItem[] deathScreenItems = {
        new Text(0, 0, "", Const.LARGE_FONT_MENU, Const.WHITE_COLOR),
    };
    Menu deathScreen = new Menu(Const.WIDTH/2 - 120, Const.HEIGHT/2-40, 240, 80, Const.DARK_GREY_COLOR, deathScreenItems);

    // Victory Screen Menu Components
    MenuItem[] victoryScreenItems = {
        new Text(125, 50, "VICTORY", Const.VERY_LARGE_FONT, Const.LIGHT_BLUE_COLOR),
        new Text(265, 240, "", Const.LARGE_FONT_MENU, Const.LIGHT_BLUE_COLOR),
        new Button(new Rect(250, 430, Const.BLACK_COLOR, 100, 50), new Text(0, 0, "BACK TO MENU", Const.VERY_LARGE_FONT_MENU, Const.LIGHT_BLUE_COLOR), MouseEvent.MOUSE_CLICKED, "Start Menu", Const.CYAN_COLOR, true, true),
    };
    Menu victoryScreen = new Menu(0, 0, Const.WIDTH, Const.HEIGHT, Const.BLACK_COLOR, victoryScreenItems);

    // Creating Grid
    Tile[][] grid = grid(0, Const.SCORE_HEIGHT, Const.ROWS, Const.COLUMNS);
    // Creating Players
    Player player1 = new Player(0, Const.SCORE_HEIGHT, Const.CYAN_COLOR, 10, 0);
    Player player2 = new Player(Const.WIDTH - Const.TILE_SIZE, 0, Const.ORANGE_COLOR, -10, 0);
    // Creating Player Variables
    int lastPositionPlayer1;
    int lastPositionPlayer2;
    boolean player1Death;
    boolean player2Death;
    // Creating Cheat
    boolean cheater;
    // Creating Invicibility Status
    boolean invincible = false;
    // Death Input Pausing
    boolean dead = false;
//------------------------------------------------------------------------------------------------------------------------------
    Tron() {
        // Creating Frame
        frame = new JFrame("TRON");
        frame.setSize(Const.WIDTH + 16, Const.HEIGHT + 39);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //Creating Canvas
        canvas = new GraphicsPanel();
        frame.add(canvas);
        // Creating Keyboard Listener
        keyboardListener = new KeyboardListener();
        canvas.addKeyListener(keyboardListener);
        // Creating Mouse Listener
        menuMouseListener = new MenuMouseListener();
        canvas.addMouseListener(menuMouseListener);
        // Creating Mouse Motion Listener
        menuMotionListener = new MenuMotionListener();
        canvas.addMouseMotionListener(menuMotionListener);
        // Setting the player's initial direction
        keyboardListener.initialDirection();
        // Setting the fram visible
        frame.setVisible(true);
        // Positioning Start Menu Items
        ((Text) startMenuItems[0]).centerText(Const.WIDTH / 2, Const.HEIGHT / 4 - 50);
        ((Button) startMenuItems[1]).centerButton(Const.WIDTH / 2, Const.HEIGHT / 2 + 140);
        ((Button) startMenuItems[2]).centerButton(Const.WIDTH / 2, Const.HEIGHT / 2 + 160);
        // Positioning Credit Menu Items
        ((Text) creditsMenuItems[0]).centerText(Const.WIDTH / 2, Const.HEIGHT / 4 - 50);
        ((Text) creditsMenuItems[1]).centerText(Const.WIDTH / 2, Const.HEIGHT / 2 - 60);
        ((Text) creditsMenuItems[2]).centerText(Const.WIDTH / 2, Const.HEIGHT / 2 - 30);
        ((Text) creditsMenuItems[3]).centerText(Const.WIDTH / 2, Const.HEIGHT / 2);
        ((Text) creditsMenuItems[4]).centerText(Const.WIDTH / 2, Const.HEIGHT / 2 + 30);
        ((Text) creditsMenuItems[5]).centerText(Const.WIDTH / 2, Const.HEIGHT / 2 + 60);
        ((Text) creditsMenuItems[6]).centerText(Const.WIDTH / 2, Const.HEIGHT / 2 + 90);
        ((Button) creditsMenuItems[7]).centerButton(Const.WIDTH / 2, Const.HEIGHT - 40);
        // Positioning Choose Difficulty Menu Items
        ((Text) chooseDifficultyMenuItems[2]).centerText(Const.WIDTH / 2, Const.HEIGHT / 2 - 20);
    }
//------------------------------------------------------------------------------------------------------------------------------
    public class GraphicsPanel extends JPanel {
        public GraphicsPanel() {
            setFocusable(true);
            requestFocusInWindow();
        }
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            // Creating Scoreboard
            g.setColor(Const.DARK_GREY_COLOR);
            g.fillRect(0, 0, Const.WIDTH, Const.HEIGHT);
            // Setting Scores on Scoreboard
            g.setColor(Const.WHITE_COLOR);
            g.setFont(Const.LARGE_FONT_MENU);
            g.drawString(String.valueOf(player1.getScore()), 20, 40);
            g.drawString(String.valueOf(player2.getScore()), Const.WIDTH - 40, 40);
            // Drawing Grid
            for (Tile[] i: grid) {
                for (Tile b: i) {
                    b.draw(g);
                }
            }
            // Drawing Players
            player1.draw(g);
            player2.draw(g);
            // Button Functions
            if (gameState.equalsIgnoreCase("Start Menu")) {
                startMenu.draw(g);
            } else if (gameState.equalsIgnoreCase("Credits Menu")) {
                creditsMenu.draw(g);
            } else if (gameState.equalsIgnoreCase("Choose Color Menu")) {
                chooseColorMenu.draw(g);
            } else if (gameState.equalsIgnoreCase("Choose Difficulty Menu")) {
                chooseDifficultyMenu.draw(g);
            } else if (gameState.equalsIgnoreCase("Victory Screen")) {
                victoryScreen.draw(g);
                // Resetting player scores between games
                player1.resetScore();
                player2.resetScore();
                cheater = false;
            }

            if (dead) {
                deathScreen.draw(g);
            }
        }
    }
//------------------------------------------------------------------------------------------------------------------------------
    public void runGameLoop() {
        // Declaring Cheat as False
        cheater = false;
        while (true) {
            frame.repaint();
            for (Tile[] i: grid) {
                for (Tile b: i) {
                    // Creating detection method of trail
                    if (player1.contains(b.getCenterX(), b.getCenterY()) && !invincible){
                        b.tint(player1.getColor());
                    }
                    if (player2.contains(b.getCenterX(), b.getCenterY())) {
                        b.tint(player2.getColor());
                    }
                }
            }
            // Defining what happens if gameState is Game, or otherwise if the game is being played
            if (gameState.equalsIgnoreCase("Game")) {
                // Player 1 move functions
                if (!invincible) {
                    player1.move();
                }
                // Player 2 move functions
                player2.move();
                // Player death variables
                player1Death = false;
                player2Death = false;
                // Creating detection of Player 1 out of bounds
                if (player1.crossingLeft(0) || player1.crossingRight(Const.WIDTH)) {
                    player1Death = true;
                }
                if (player1.crossingTop(Const.SCORE_HEIGHT) || player1.crossingBottom(Const.HEIGHT)) {
                    player1Death = true;
                }
                // Creating detection of Player 2 out of bounds
                if (player2.crossingLeft(0) || player2.crossingRight(Const.WIDTH)) {
                    player2Death = true;
                }
                if (player2.crossingTop(Const.SCORE_HEIGHT) || player2.crossingBottom(Const.HEIGHT)) {
                    player2Death = true;
                }
                // Defining what player death is
                for (Tile[] i: grid) {
                    for (Tile b: i) {
                        if (player1.contains(b.getCenterX(), b.getCenterY())&& !invincible) {
                            if (b.killer()) {
                                player1Death = true;
                            }
                        }
                        if (player2.contains(b.getCenterX(), b.getCenterY())) {
                            if (b.killer()) {
                                player2Death = true;
                            }
                        }
                    }
                }
                // Defining what happens when player death occurs
                if (player2Death || player1Death) {
                    dead = true;

                    if (Const.MUSIC.isRunning()) {
                        Const.MUSIC.stop();
                        Const.MUSIC.flush();
                    }

                    // Death sound implementation
                    Const.DEATH_SOUND.setFramePosition(0);
                    Const.DEATH_SOUND.start();

                    // Defining point at which player wins and what happens when they win
                    if (player1.getScore() >= 2) {
                        dead = false;
                        gameState = "Victory Screen";
                        // Setting victory text to the color of the player (for look)
                        ((Text) victoryScreenItems[0]).setColor(player1.getColor());
                        ((Text) victoryScreenItems[1]).setText("PLAYER 1 HAS WON");
                    } else if (player2.getScore() >= 2) {
                        dead = false;
                        gameState = "Victory Screen";
                        // Setting victory text to the color of the player (for look)
                        ((Text) victoryScreenItems[0]).setColor(player2.getColor());
                        ((Text) victoryScreenItems[1]).setText("PLAYER 2 HAS WON");
                    } else {
                        if (player1Death && player2Death) {
                            ((Text)(deathScreenItems[0])).setText("Tie!");
                        } else if (player1Death) {
                            ((Text)(deathScreenItems[0])).setText("Player 1 died!");
                            player2.addPlayerScore();
                        } else if (player2Death) {
                            ((Text)(deathScreenItems[0])).setText("Player 2 died!");
                            player1.addPlayerScore();
                        }
                        ((Text)(deathScreenItems[0])).centerText(deathScreen.getX() + deathScreen.getWidth()/2, deathScreen.getY() + deathScreen.getHeight()/2);

                        frame.repaint();

                        try {
                            Thread.sleep(4000);
                        } catch (Exception e) {}

                        this.reset(player2Death, player1Death);
                    }
                }
            }
            try {
                Thread.sleep(difficultyInt);
            } catch (Exception e) {}
        }
    }
    
    /** 
     * Depending on which player died, the method will reset the grid and player
     * @param player2Death
     * @param player1Death
     */
    public void reset(boolean player2Death, boolean player1Death) {
        Const.COUNT_SOUND.setFramePosition(0);
        Const.COUNT_SOUND.start();
        if (gameState.equalsIgnoreCase("Victory Screen")) {
            Const.COUNT_SOUND.stop();
        }
        try {
            Thread.sleep(1000);
        } catch (Exception e) {}
        try {
            Thread.sleep(1000);
        } catch (Exception e) {}
        try {
            Thread.sleep(1000);
        } catch (Exception e) {}
        Const.MUSIC.setFramePosition(0);
        Const.MUSIC.start();
        for (Tile[] i: grid) {
            for (Tile b: i) {
                b.reset();
            }
        }
        // Defiining where players get reset to
        player1.reset(0, Const.SCORE_HEIGHT);
        player2.reset(Const.WIDTH - Const.TILE_SIZE, Const.SCORE_HEIGHT);
        player1.right();
        player2.left();
        dead = false;
    }
//------------------------------------------------------------------------------------------------------------------------------
    public class KeyboardListener implements KeyListener {
        public void keyPressed(KeyEvent e) {
            int key = e.getKeyCode();
            // Defining what happens when gameState is equal to Game
            if (gameState.equalsIgnoreCase("Game") && !dead) {
                if ((key == KeyEvent.VK_SPACE) && (!cheater)) {
                    // Phase cheat and cheat sound
                    Const.CHEAT_SOUND.setFramePosition(0);
                    Const.CHEAT_SOUND.start();
                    this.phase(player1);
                    cheater = true;
                }
                // Player 1 key controls
                if ((key == KeyEvent.VK_A) && (player1.xPositive())) {
                    player1.left();
                    lastPositionPlayer1 = key;
                } else if ((key == KeyEvent.VK_D) && (player1.xPositive())) {
                    player1.right();
                    lastPositionPlayer1 = key;
                } else if ((key == KeyEvent.VK_W) && (player1.yPositive())) {
                    player1.up();
                    lastPositionPlayer1 = key;
                } else if ((key == KeyEvent.VK_S) && (player1.yPositive())) {
                    player1.down();
                    lastPositionPlayer1 = key;
                }
                //Player 2 key controls
                if ((key == KeyEvent.VK_LEFT) && (player2.xPositive())) {
                    player2.left();
                    lastPositionPlayer2 = key;
                } else if ((key == KeyEvent.VK_RIGHT) && (player2.xPositive())) {
                    player2.right();
                    lastPositionPlayer2 = key;
                } else if ((key == KeyEvent.VK_UP) && (player2.yPositive())) {
                    player2.up();
                    lastPositionPlayer2 = key;
                } else if ((key == KeyEvent.VK_DOWN) && (player2.yPositive())) {
                    player2.down();
                    lastPositionPlayer2 = key;
                }
            }
        }
        public void keyReleased(KeyEvent e) {}
        public void keyTyped(KeyEvent e) {}
        public void initialDirection() {
            lastPositionPlayer1 = KeyEvent.VK_RIGHT;
            lastPositionPlayer2 = KeyEvent.VK_A;
        }
        // Phase cheat method
        public void phase(Player player) {
            invincible = true;
            for (int i = 0; i < 15; i++) {
                for (Tile[] r: grid) {
                    for (Tile c: r) {
                        if (player.contains(c.getCenterX(), c.getCenterY())) {
                            Color randomRed = new Color(((int)(75 * Math.random()) + 180), 0, 0);
                            c.tint(randomRed);
                        }
                    }
                }
                player.move();
            }
            invincible = false;
        }
    }
//------------------------------------------------------------------------------------------------------------------------------
    public class MenuMouseListener implements MouseListener {
        public void mouseClicked(MouseEvent e) { // listens to clicks
            int mouseX = e.getX();
            int mouseY = e.getY();
            // Click sound implementation
            Const.CLICK_SOUND.setFramePosition(0);
            Const.CLICK_SOUND.start();

            callRanButtons(mouseX, mouseY, MouseEvent.MOUSE_CLICKED);
        }
        public void mousePressed(MouseEvent e) { // MUST be implemented even if not used!
            int mouseX = e.getX();
            int mouseY = e.getY();

            callRanButtons(mouseX, mouseY, MouseEvent.MOUSE_PRESSED);
        }
        public void mouseReleased(MouseEvent e) { // MUST be implemented even if not used!
            int mouseX = e.getX();
            int mouseY = e.getY();

            callRanButtons(mouseX, mouseY, MouseEvent.MOUSE_RELEASED);
        }
        public void mouseEntered(MouseEvent e) { // MUST be implemented even if not used!
            int mouseX = e.getX();
            int mouseY = e.getY();

            callRanButtons(mouseX, mouseY, MouseEvent.MOUSE_ENTERED);
        }
        public void mouseExited(MouseEvent e) { // MUST be implemented even if not used!
            int mouseX = e.getX();
            int mouseY = e.getY();

            callRanButtons(mouseX, mouseY, MouseEvent.MOUSE_EXITED);
        }
    }
//------------------------------------------------------------------------------------------------------------------------------
    public class MenuMotionListener implements MouseMotionListener {
        public void mouseDragged(MouseEvent e) { // MUST be implemented even if not used!
        }
        public void mouseMoved(MouseEvent e) { // MUST be implemented even if not used!
            int mouseX = e.getX();
            int mouseY = e.getY();
            System.out.println(e.getX());
            System.out.println(e.getY());

            if (!(gameState.equalsIgnoreCase("Game"))) {
                hoverButtons(mouseX, mouseY);
            }
        }
    }
//------------------------------------------------------------------------------------------------------------------------------
    /** 
    * Check if any button in the current game state menu is colliding with the mouse.
    * If so, change the button to its hover color, otherwise, reset the button to the original color.
    * @param mouseX
    * @param mouseY
    */
    public void hoverButtons(int mouseX, int mouseY) {
        if (gameState.equalsIgnoreCase("Start Menu")) {
            startMenu.resetButtons();

            ArrayList < Integer > hoveredButtons = startMenu.findCollidedButtons(mouseX, mouseY);

            for (int hoveredButtonIndex: hoveredButtons) {
                Button hoveredButton = ((Button) startMenu.getMenuItem(hoveredButtonIndex));

                hoveredButton.hoveredColor();
            }
        } else if (gameState.equalsIgnoreCase("Credits Menu")) {
            creditsMenu.resetButtons();

            ArrayList < Integer > hoveredButtons = creditsMenu.findCollidedButtons(mouseX, mouseY);

            for (int hoveredButtonIndex: hoveredButtons) {
                Button hoveredButton = ((Button) creditsMenu.getMenuItem(hoveredButtonIndex));

                hoveredButton.hoveredColor();
            }
        } else if (gameState.equalsIgnoreCase("Choose Color Menu")) {
            chooseColorMenu.resetButtons();

            ArrayList < Integer > hoveredButtons = chooseColorMenu.findCollidedButtons(mouseX, mouseY);

            for (int hoveredButtonIndex: hoveredButtons) {
                Button hoveredButton = ((Button) chooseColorMenu.getMenuItem(hoveredButtonIndex));
                hoveredButton.hoveredColor();
            }
        } else if (gameState.equalsIgnoreCase("Choose Difficulty Menu")) {
            chooseDifficultyMenu.resetButtons();

            ArrayList < Integer > hoveredButtons = chooseDifficultyMenu.findCollidedButtons(mouseX, mouseY);

            for (int hoveredButtonIndex: hoveredButtons) {
                Button hoveredButton = ((Button) chooseDifficultyMenu.getMenuItem(hoveredButtonIndex));
                hoveredButton.hoveredColor();
            }
        } else if (gameState.equalsIgnoreCase("Victory Screen")) {
            victoryScreen.resetButtons();

            ArrayList < Integer > hoveredButtons = victoryScreen.findCollidedButtons(mouseX, mouseY);

            for (int hoveredButtonIndex: hoveredButtons) {
                Button hoveredButton = ((Button) victoryScreen.getMenuItem(hoveredButtonIndex));
                hoveredButton.hoveredColor();
            }
        }
    }
//------------------------------------------------------------------------------------------------------------------------------
/** 
 * Check if any of the button's in the current game state has been collided with and activated.
 * If so, run their custom button function. 
 * @param mouseX
 * @param mouseY
 * @param mouseEvent
 */
    public void callRanButtons(int mouseX, int mouseY, int mouseEvent) {
        if (gameState.equalsIgnoreCase("Start Menu")) {
            ArrayList < Integer > ranButtons = startMenu.findCollidedButtons(mouseX, mouseY);

            for (int ranButtonIndex: ranButtons) {
                Button ranButton = ((Button) startMenu.getMenuItem(ranButtonIndex));
                if (ranButton.checkButtonType(mouseEvent)) {
                    runButtonFunction(ranButton.getButtonFunction());
                }
            }
        } else if (gameState.equalsIgnoreCase("Credits Menu")) {
            ArrayList < Integer > ranButtons = creditsMenu.findCollidedButtons(mouseX, mouseY);

            for (int ranButtonIndex: ranButtons) {
                Button ranButton = ((Button) creditsMenu.getMenuItem(ranButtonIndex));
                if (ranButton.checkButtonType(mouseEvent)) {
                    runButtonFunction(ranButton.getButtonFunction());
                }
            }
        } else if (gameState.equalsIgnoreCase("Choose Color Menu")) {
            ArrayList < Integer > ranButtons = chooseColorMenu.findCollidedButtons(mouseX, mouseY);

            for (int ranButtonIndex: ranButtons) {
                Button ranButton = ((Button) chooseColorMenu.getMenuItem(ranButtonIndex));
                if (ranButton.checkButtonType(mouseEvent)) {
                    runButtonFunction(ranButton.getButtonFunction());
                }
            }
        } else if (gameState.equalsIgnoreCase("Choose Difficulty Menu")) {
            ArrayList < Integer > ranButtons = chooseDifficultyMenu.findCollidedButtons(mouseX, mouseY);

            for (int ranButtonIndex: ranButtons) {
                Button ranButton = ((Button) chooseDifficultyMenu.getMenuItem(ranButtonIndex));
                if (ranButton.checkButtonType(mouseEvent)) {
                    runButtonFunction(ranButton.getButtonFunction());
                }
            }
        } else if (gameState.equalsIgnoreCase("Victory Screen")) {
            ArrayList < Integer > ranButtons = victoryScreen.findCollidedButtons(mouseX, mouseY);

            for (int ranButtonIndex: ranButtons) {
                Button ranButton = ((Button) victoryScreen.getMenuItem(ranButtonIndex));
                if (ranButton.checkButtonType(mouseEvent)) {
                    runButtonFunction(ranButton.getButtonFunction());
                }
            }
        }
    }
//------------------------------------------------------------------------------------------------------------------------------
/** 
 * Contains the functionality of every custom button function.
 * @param buttonFunction
 */
    public void runButtonFunction(String buttonFunction) {
        if (buttonFunction.equalsIgnoreCase("Start Menu")) {
            gameState = "Start Menu";
        } else if (buttonFunction.equalsIgnoreCase("Credits Menu")) {
            gameState = "Credits Menu";
        } else if (buttonFunction.equalsIgnoreCase("Choose Color Menu")) {
            gameState = "Choose Color Menu";
        } else if (buttonFunction.equalsIgnoreCase("Game")) {
            reset(false, false);

            String difficulty = difficultyCycle[currentDifficultyCycle];
            if (difficulty.equalsIgnoreCase("Easy Level")) {
                difficultyInt = Const.DELAY_EASYLEVEL;
            }
            if (difficulty.equalsIgnoreCase("Medium Level")) {
                difficultyInt = Const.DELAY_MEDIUMLEVEL;
            }
            if (difficulty.equalsIgnoreCase("Hard Level")) {
                difficultyInt = Const.DELAY_HARDLEVEL;
            }

            gameState = "Game";
            //Player 1 Left
        } else if (buttonFunction.equalsIgnoreCase("P1 Cycle Color Left")) {
            if (currentCycleP1 == 0) {
                currentCycleP1 = playerColorCycle.length - 1;
            } else {
                currentCycleP1 -= 1;
            }
            player1.setColor(playerColorCycle[currentCycleP1]);
            chooseColorItems[2].setColor(playerColorCycle[currentCycleP1]);
            //Player 1 Right
        } else if (buttonFunction.equalsIgnoreCase("P1 Cycle Color Right")) {
            if (currentCycleP1 == playerColorCycle.length - 1) {
                currentCycleP1 = 0;
            } else {
                currentCycleP1 += 1;
                player1.setColor(playerColorCycle[currentCycleP1]);
            }
            chooseColorItems[2].setColor(playerColorCycle[currentCycleP1]);
            //Player 2 Left
        } else if (buttonFunction.equalsIgnoreCase("P2 Cycle Color Left")) {
            if (currentCycleP2 == 0) {
                currentCycleP2 = playerColorCycle.length - 1;
            } else {
                currentCycleP2 -= 1;
            }
            player2.setColor(playerColorCycle[currentCycleP2]);
            chooseColorItems[7].setColor(playerColorCycle[currentCycleP2]);
            //Player 2 Right
        } else if (buttonFunction.equalsIgnoreCase("P2 Cycle Color Right")) {
            if (currentCycleP2 == playerColorCycle.length - 1) {
                currentCycleP2 = 0;
            } else {
                currentCycleP2 += 1;
                player2.setColor(playerColorCycle[currentCycleP2]);
            }
            chooseColorItems[7].setColor(playerColorCycle[currentCycleP2]);
        } else if (buttonFunction.equalsIgnoreCase("Choose Difficulty Menu")) {
            gameState = "Choose Difficulty Menu";
        } else if (buttonFunction.equalsIgnoreCase("Choose Difficulty Cycle Left")) {
            //Left Cycle
            if (currentDifficultyCycle == 0) {
                currentDifficultyCycle = difficultyCycle.length - 1;
            } else {
                currentDifficultyCycle -= 1;
            }
            ((Text) chooseDifficultyMenuItems[2]).setText(difficultyCycle[currentDifficultyCycle]);
            ((Text) chooseDifficultyMenuItems[2]).centerText(Const.WIDTH / 2, Const.HEIGHT / 2 - 20);
        } else if (buttonFunction.equalsIgnoreCase("Choose Difficulty Cycle Right")) {
            //Right Cycle
            if (currentDifficultyCycle == difficultyCycle.length - 1) {
                currentDifficultyCycle = 0;
            } else {
                currentDifficultyCycle += 1;
            }
            ((Text) chooseDifficultyMenuItems[2]).setText(difficultyCycle[currentDifficultyCycle]);
            ((Text) chooseDifficultyMenuItems[2]).centerText(Const.WIDTH / 2, Const.HEIGHT / 2 - 20);
        }
    }
//------------------------------------------------------------------------------------------------------------------------------
/** 
 * Creates a 2D array of Tile objects.
 * Can be offset by x and y arguments.
 * @param x
 * @param y
 * @param rows
 * @param columns
 * @return Tile[][]
 */
//------------------------------------------------------------------------------------------------------------------------------
    public Tile[][] grid(int x, int y, int rows, int columns) {
        Tile[][] grid = new Tile[rows][columns];
        for (int i = 0; i < rows; i++) {
            for (int b = 0; b < columns; b++) {
                grid[i][b] = new Tile(x + i * 10, y + b * 10, Const.BLACK_COLOR);
            }
        }
        return grid;
    }
//------------------------------------------------------------------------------------------------------------------------------
    public static void main(String[] args) {
        Tron b = new Tron();
        b.runGameLoop();
    }
}