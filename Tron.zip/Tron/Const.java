import java.awt.Color;
import java.awt.Font;

public class Const {
    public static final int WIDTH = 800;
    public static final int SCORE_HEIGHT = 50;
    public static final int HEIGHT = 600 + SCORE_HEIGHT;
    public static final int TILE_SIZE = 10;
    public static final int STEP = 10;
    public static final int ROWS = WIDTH / TILE_SIZE;
    public static final int COLUMNS = (HEIGHT - SCORE_HEIGHT) / TILE_SIZE;
    public static final int DELAY_EASYLEVEL = 60;
    public static final int DELAY_MEDIUMLEVEL = 48;
    public static final int DELAY_HARDLEVEL = 20;
    public static final Color ORANGE_COLOR = new Color(223, 116, 12);
    public static final Color YELLOW_COLOR = new Color(255, 230, 77);
    public static final Color LIGHT_BLUE_COLOR = new Color(230, 255, 255);
    public static final Color CYAN_COLOR = new Color(111, 195, 223);
    public static final Color BLACK_COLOR = new Color(12, 20, 31);
    public static final Color DARK_GREY_COLOR = new Color(77, 80, 80);
    public static final Color LIGHT_GREY_COLOR = new Color(144, 144, 144);
    public static final Color WHITE_COLOR = new Color(255, 255, 255);

    private static final Font TRON_FONT = CustomFont.loadFont("Fonts/Tron-JOAa.ttf", 10);
    private static final Font MENU_FONT = CustomFont.loadFont("Fonts//FutureForcesCondensed-4AMl.otf", 10);

    public static final Font SMALL_FONT = TRON_FONT.deriveFont(12f);
    public static final Font MEDIUM_FONT = TRON_FONT.deriveFont(24f);
    public static final Font LARGE_FONT = TRON_FONT.deriveFont(48f);
    public static final Font VERY_LARGE_FONT = TRON_FONT.deriveFont(96f);

    public static final Font SMALL_FONT_MENU = MENU_FONT.deriveFont(12f);
    public static final Font MEDIUM_FONT_MENU = MENU_FONT.deriveFont(24f);
    public static final Font LARGE_FONT_MENU = MENU_FONT.deriveFont(36f);
    public static final Font VERY_LARGE_FONT_MENU = MENU_FONT.deriveFont(48f);

    public static final Sound CHEAT_SOUND = new Sound("Audio/Cheat.wav");
    public static final Sound DEATH_SOUND = new Sound("Audio/Death.wav");
    public static final Sound MUSIC = new Sound("Audio/Music.wav");
    public static final Sound COUNT_SOUND = new Sound("Audio/Count.wav");
    public static final Sound CLICK_SOUND = new Sound("Audio/Click.wav");
    private Const() {}
}