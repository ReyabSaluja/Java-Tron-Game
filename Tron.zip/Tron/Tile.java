import java.awt.Graphics;
import java.awt.*;

/**
 * The Tile class is a singlular square on the game grid.
 * @see Tron
 * @author Reyab Saluja
 * @version "1.8.0_322"
 */
public class Tile{
    private int x;
    private int y; 
    private int width;
    private int height; 
    private Color color;
    private boolean kills;
    private int centerX;
    private int centerY;
    
    final private int TILE_SIZE = 10;
//------------------------------------------------------------------------------     
    Tile(int x, int y, Color color){
        this.x = x;
        this.y = y;
        this.color = color;
        this.centerX = x+TILE_SIZE/2;
        this.centerY = y+TILE_SIZE/2;
    }  
//------------------------------------------------------------------------------

	public int getX() {
		return this.x;
	}
	
	public int getY() {
		return this.y;
	}
	
	public int getWidth() {
		return this.width;
	}
	
	public int getHeight() {
		return this.height;
	}
	
	public Color getColor() {
		return this.color;
	}
	
	public int getCenterX() {
		return this.centerX;
	}
	
	public int getCenterY() {
		return this.centerY;
	}
	
	public void setX(int x) {
		this.x = x;
	}
	
	public void setY(int y) {
		this.y = y;
	}
	
	public void setWidth(int width) {
		this.width = width;
	}
	
	public void setHeight(int height) {
		this.height = height;
	}
	
	public void setColor(Color color) {
		this.color = color;
	}
	
	public void setCenterX(int centerX) {
		this.centerX = centerX;
	}
	
	public void setCenterY(int centerY) {
		this.centerY = centerY;
	}
    
	public boolean killer() {
		return this.kills;
    }
	
	/** 
	 * Changes the tile's color and turns into a killer tile.
	 * @param color
	 */
	public void tint(Color color) {
		this.color = color;
		this.kills = true;
	  }
	//------------------------------------------------------------------------------     

    /** 
     * Draws the rect onto a Graphics panel.
     * @param g
     */
    public void draw(Graphics g){
        g.setColor(this.color);
        g.fillRect(this.x,this.y,TILE_SIZE,TILE_SIZE);
    }    

    /** 
     * Resets the status and color of this tile.
     * @param g
     */
    public void reset(){
      this.kills = false;
      this.color = Const.BLACK_COLOR;
    }
//------------------------------------------------------------------------------     
}